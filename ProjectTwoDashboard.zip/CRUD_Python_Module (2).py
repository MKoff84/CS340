from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelterCRUD:
    """Provide Create, Read, Update, and Delete access to the AAC animals collection."""

    def __init__(self, username, password,
                 host="localhost", port=27017,
                 db_name="aac", collection_name="animals"):
        """Initialize MongoDB connection using provided credentials."""
        try:
            uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
            self.client = MongoClient(uri)
            self.client.admin.command("ping")
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as e:
            print(f"Connection error: {e}")

    def create(self, data):
        """Insert a document into the collection. Return True if successful, else False."""
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as e:
                print(f"Insert failed: {e}")
                return False
        return False

    def read(self, query, projection=None):
        """
        Query documents using find().
        - query: dict (filter)
        - projection: dict (optional), e.g. {"_id": 0}
        Return a list of results or an empty list.
        """
        if query is None:
            query = {}

        results = []
        try:
            cursor = self.collection.find(query, projection)
            results = list(cursor)
        except PyMongoError as e:
            print(f"Read failed: {e}")
        return results

    def update(self, query, new_values, multiple=False):
        """
        Update document(s) in the collection.
        Returns number of documents modified.
        """
        if not isinstance(query, dict) or not isinstance(new_values, dict) or not new_values:
            return 0

        try:
            update_doc = {"$set": new_values}
            result = self.collection.update_many(query, update_doc) if multiple else self.collection.update_one(query, update_doc)
            return result.modified_count
        except PyMongoError as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, query, multiple=False):
        """
        Delete document(s) from the collection.
        Returns number of documents deleted.
        """
        if not isinstance(query, dict) or not query:
            return 0

        try:
            result = self.collection.delete_many(query) if multiple else self.collection.delete_one(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Read failed: {e}")
        return results